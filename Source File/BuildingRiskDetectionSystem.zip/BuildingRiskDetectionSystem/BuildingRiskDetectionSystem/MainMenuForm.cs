﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class MainMenuForm : Form
    {
        FormControlsResize formControlsResize = new FormControlsResize();
        Dictionary<string, DeviceForm> formSet = new Dictionary<string, DeviceForm>();
        string uid = string.Empty;
        Device[] devices = new Device[256];
        int deviceCount = 0;

        public static Control Tourist_Temp_Device = new Control();
        public static bool NeedRefresh = false;

        public MainMenuForm()
        {
            InitializeComponent();
        }

        public MainMenuForm(string uid)
        {
            InitializeComponent();
            this.uid = uid;
        }

        private void Tourist_Load_Device()
        {           
            string[] url =
            {
                "http://api.heclouds.com/devices/803954396",
                "http://api.heclouds.com/devices/803954396",
                "http://api.heclouds.com/devices/820069991",
                "http://api.heclouds.com/devices/820086592",
                "http://api.heclouds.com/devices/820099505",
                "http://api.heclouds.com/devices/820169078",
                "http://api.heclouds.com/devices/820180355",
                "http://api.heclouds.com/devices/820194183",
                "http://api.heclouds.com/devices/820203655",
                "http://api.heclouds.com/devices/820209930",
                "http://api.heclouds.com/devices/820217145"
            };
            string[] api_key =
            {
                "JuydKoupczTM7JUGZJAw3b7nd38=",
                "JuydKoupczTM7JUGZJAw3b7nd38=",
                "qSdsf6ZUDXGiUmGig5hVQSghbVI=",
                "K=AoA5YDyoXu=5Ng7wDaivtyWlg=",
                "lLGK=hWWzCcT9vEvy8SD3SzEUCQ=",
                "dkAjc9V7eobGGm8BeBCnL7GGqO4=",
                "Gogu9iagY5IhdOqgdv5N0ZXEl=8=",
                "kYlnTU1IFJcXoVwkTTKryW9Aobg=",
                "wu8RrvAA9PaVRykf8Mshk5=hI8A=",
                "jye8l1S8UjryDRygZan68g6VwcM=",
                "ENua9EIYhj1ESDXx8=g3zhG=fio="
            };
            deviceCount = Math.Min(url.Length, api_key.Length);
            for (int i = 0; i < deviceCount; ++i)
            {
                devices[i] = new Device();
                devices[i].Device_id = Device.GetDeviceIdFromUrl(url[i]);
                devices[i].Device_name = Device.allDeviceType[i] + "传感器";
                devices[i].Device_type = Device.allDeviceType[i] + "," + Device.oneNetApiName[i];
                devices[i].Url = url[i];
                devices[i].Api_key = api_key[i];
            }
        }

        private ListView Load_Overview_ListView()
        {
            ListView listView = new ListView();
            listView.Dock = DockStyle.Fill;
            listView.MultiSelect = false;
            for (int i = 0; i < deviceCount; ++i)
            {
                ListViewItem item = new ListViewItem();
                item.BackColor = Color.Silver;
                item.Text = devices[i].Device_name;
                item.Tag = devices[i];
                listView.Items.Add(item);
            }
            return listView;
        }

        private void TabControls_Load()
        {
            foreach (TabPage tabPage in tabControl1.TabPages)
            {
                tabPage.Controls.Clear();
            }
            tabPage1.Controls.Add(Load_Overview_ListView());
            foreach (TabPage tabPage in tabControl1.TabPages)
            {
                ListView listView = new ListView();
                listView.Dock = DockStyle.Fill;
                listView.MultiSelect = false;
                tabPage.Controls.Add(listView);
            }
            for (int i = 0; i < deviceCount; ++i)
            {
                ListViewItem item = new ListViewItem();
                item.BackColor = Color.Silver;
                item.Text = devices[i].Device_name;
                item.Tag = devices[i];
                ((ListView)tabControl1.TabPages[devices[i].GetIdx() + 1].Controls[0]).Items.Add(item);
            }

        }

        private void Tourist_Check()
        {
            if (Tourist_Temp_Device.Tag == null) return;
            int idx = 0;
            for (; idx < deviceCount; ++idx)
            {
                if (((Device)Tourist_Temp_Device.Tag).GetDeviceUniqueCode() == devices[idx].GetDeviceUniqueCode())
                {
                    devices[idx] = (Device)Tourist_Temp_Device.Tag;
                    Tourist_Temp_Device.Tag = null;
                    break;
                }
            }
            if (idx == deviceCount)
            {
                devices[idx] = (Device)Tourist_Temp_Device.Tag;
                Tourist_Temp_Device.Tag = null;
                ++deviceCount;
            }
        }

        private void Tourist_Mode()
        {
            Tourist_Check();
            TabControls_Load();
        }

        private void Tourist_Load()
        {
            Tourist_Load_Device();
            TabControls_Load();
        }

        private void User_Load_Device()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "SELECT * FROM user_device_tb WHERE uid = '" + uid + "';";
            DataTable userAllDevice = new DataTable();
            userAllDevice = mySQLConnect.ExecuteQuery(sqlStr);
            deviceCount = 0;
            for (int i = 0; i < userAllDevice.Rows.Count; ++i)
            {
                string device_id = userAllDevice.Rows[i]["device_id"].ToString();
                sqlStr = "SELECT * FROM device_tb WHERE device_id = '" + device_id + "';";               
                DataTable newDevice = new DataTable();
                newDevice = mySQLConnect.ExecuteQuery(sqlStr);
                devices[deviceCount] = new Device(newDevice);
                devices[deviceCount].Device_name = userAllDevice.Rows[i]["device_name"].ToString();
                devices[deviceCount].Device_type = userAllDevice.Rows[i]["device_type"].ToString();
                ++deviceCount;
            }
        }

        private DataTable Load_OneNetRecord(Device device, DateTime dateTime)
        {
            string datastream_id = device.GetDeviceType();
            string start = dateTime.ToString("yyyy-MM-ddTHH:mm:ss");
            string limit = 3600.ToString();
            string url = device.Url + "/datapoints?datastream_id=" + datastream_id + "&start=" + start + "&limit=" + limit;
            //MessageBox.Show(url);
            OneNetConnect oneNetConnect = new OneNetConnect();
            string oneNetStr = oneNetConnect.Get(url, device.Api_key);
            DataTable dataTable = new DataTable();
            dataTable = oneNetConnect.GetRecordDataTable(oneNetStr);
            return dataTable;
        }

        private DateTime Get_MySqlCurrentAt(Device device)
        {
            DateTime dateTime = new DateTime();
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "SELECT * FROM record_tb WHERE device_id = '" + device.Device_id
                + "' AND device_type = '" + device.Device_type
                + "' ORDER BY at DESC LIMIT 1;";
            DataTable dataTable = new DataTable();
            dataTable = mySQLConnect.ExecuteQuery(sqlStr);
            dateTime = dataTable.Rows.Count == 0 ? DateTime.Now.AddYears(-4) : Convert.ToDateTime(dataTable.Rows[0]["at"].ToString());
            return dateTime;
        }

        private bool Update_MySqlRecord(Device device, DataTable dataTable)
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            int successCount = 0;
            for(int i = 0; i < dataTable.Rows.Count; ++i)
            {
                string sqlStr = "SELECT * FROM record_tb WHERE device_id = '" + device.Device_id
                    +"' AND device_type = '" + device.Device_type
                    + "' AND at = '" + dataTable.Rows[i]["at"].ToString()
                    +"';";
                if(mySQLConnect.ExecuteQuery(sqlStr).Rows.Count != 0)
                {
                    continue;
                }
                sqlStr = "INSERT INTO record_tb VALUES('" + device.Device_id 
                    + "','" + device.Device_type
                    +"','" + dataTable.Rows[i]["value"].ToString()
                    +"','" + dataTable.Rows[i]["at"].ToString()
                    + "');";
                successCount += mySQLConnect.ExecuteUpdate(sqlStr);
            }
            return successCount == dataTable.Rows.Count;
        }
        private void Update_OneNetRecord_To_MySqlRecord()
        {
            for(int i = 0; i < deviceCount; ++i)
            {
                DateTime current_at = Get_MySqlCurrentAt(devices[i]);
                DataTable dataTable = Load_OneNetRecord(devices[i], current_at.AddSeconds(1));
                Update_MySqlRecord(devices[i], dataTable);
            }
        }

        private void User_Mode()
        {
            User_Load_Device();
            TabControls_Load();           
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
            formControlsResize.Initialize2(this);
            //formControlsResize.Initialize(statusStrip1);
            if(uid == string.Empty)
            {
                toolStripStatusLabel1.Text = "游客模式";
                Tourist_Load();
            }
            else
            {
                toolStripStatusLabel1.Text = "当前登入账号：" + uid;
                User_Mode();
                Update_OneNetRecord_To_MySqlRecord();
            }
        }

        private void Form2_Resize(object sender, EventArgs e)
        {
            //tabControl1控件有问题
            //formControlsResize.Resize(this);
            formControlsResize.Resize2(this);
            //formControlsResize.Resize(statusStrip1);
        }

        private bool User_Delete_Device(Device device)
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "DELETE FROM user_device_tb WHERE uid = '" + uid
                + "' AND device_id = '" + device.Device_id
                + "' AND device_type = '" + device.Device_type
                + "';";
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        private bool Tourist_Delete_Device(Device device)
        {
            for(int i = 0; i < deviceCount; ++i)
            {
                if (device.GetDeviceUniqueCode() == devices[i].GetDeviceUniqueCode())
                {
                    --deviceCount;
                    for(int j = i; j < deviceCount; ++j)
                    {
                        devices[j] = devices[j + 1];
                    }                    
                    return true;
                }
            }
            return false;
        }

        private bool Delete_Device(Device device)
        {
            if(uid == string.Empty)
            {
                return Tourist_Delete_Device(device);
            }
            else
            {
                return User_Delete_Device(device);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Control control = Get_Select_Item();
            if (control == null)
            {
                MessageBox.Show("当前未选中任何传感器！", "删除错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string deviceUniqueCode = ((Device)control.Tag).GetDeviceUniqueCode();
            if(formSet.ContainsKey(deviceUniqueCode)) formSet[deviceUniqueCode].Close();
            DialogResult dialogResult = MessageBox.Show("是否将此设备从您的库中移除？", "删除确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                if (Delete_Device((Device)control.Tag))
                {                  
                    NeedRefresh = true;
                    this.Activate();
                    MessageBox.Show("设备已从您的库中移除！", "删除成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("设备未能成功移除！", "删除失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private Control Get_Select_Item()
        {         
            foreach (Control con in tabControl1.SelectedTab.Controls)
            {
                if (con is ListView)
                {
                    ListView listView = new ListView();
                    listView = (ListView)con;
                    if (listView.SelectedItems.Count > 0)
                    {
                        Control control = new Control();
                        control.Tag = listView.SelectedItems[0].Tag;
                        return control;
                    }
                }
            }
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Control control = Get_Select_Item();
            if(control == null)
            {
                MessageBox.Show("当前未选中任何传感器！", "查看错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DeviceForm form6 = new DeviceForm(uid, control);
            string deviceUniqueCode = ((Device)control.Tag).GetDeviceUniqueCode();
            if (formSet.ContainsKey(deviceUniqueCode) && !formSet[deviceUniqueCode].IsDisposed)
            {
                //formSet[deviceUniqueCode].Show();
                formSet[deviceUniqueCode].Activate();
            }
            else
            {
                formSet[deviceUniqueCode] = form6;
                form6.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddDeviceForm form5 = new AddDeviceForm(uid);
            form5.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void allDeviceForm_Close()
        {
            foreach (KeyValuePair<string, DeviceForm> item in formSet)
            {
                item.Value.Close();
            }
            formSet.Clear();
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            allDeviceForm_Close();
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void MainMenuForm_Activated(object sender, EventArgs e)
        {
            if (NeedRefresh == false) return;
            //MessageBox.Show("!!!!");
            if(uid != string.Empty)
            {
                User_Mode();          
            }
            else
            {
                Tourist_Mode();
            }
            NeedRefresh = false;
        }

        private void MainMenuForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
