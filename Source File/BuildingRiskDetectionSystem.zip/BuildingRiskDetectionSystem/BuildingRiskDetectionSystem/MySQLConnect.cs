﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    /// <summary>
    /// 一个连接MySQL数据库的类
    /// </summary>
    public class MySQLConnect
    {
        /// <summary>
        /// 数据库地址
        /// </summary>
        private static string connetStr =
       "data source=127.0.0.1;database=building_risk_detection_system_db;user id=root;password=lgc2621690255;";
       //"Server=server.natappfree.cc;Port=38390;Stmt=;Database=building_risk_detection_system_db;Uid=root;Pwd=lgc2621690255;";
        /// <summary>
        /// 连接数据库，不成功时抛出异常
        /// </summary>
        /// <returns></returns>
        private MySqlConnection Connect()
        {
            MySqlConnection conn = new MySqlConnection(connetStr);                   
            try
            {     
                conn.Open();           
                if (conn.State == ConnectionState.Open)
                {
                    return conn;
                    //MessageBox.Show("连接成功！", "连接信息");
                }
                else
                {
                    MessageBox.Show("数据库连接失败！", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("数据库连接失败！", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public static void SetMySqlAdress(string port)
        {
            connetStr = "Server = server.natappfree.cc; Port =" + port + ";Stmt=;Database=building_risk_detection_system_db;Uid=root;Pwd=lgc2621690255;";
        }

        /// <summary>
        /// 执行查询操作 传入sql语句 返回查询结果
        /// </summary>
        /// <param name="sqlStr">sql语句</param>
        /// <returns>查询结果</returns>
        public DataTable ExecuteQuery(string sqlStr)
        {
            MySqlConnection conn = Connect(); //连接数据库
            DataTable dataTable = new DataTable();
            if (conn == null) return dataTable;
            conn.Open(); //打开数据库连接
            MySqlCommand cmd = new MySqlCommand(sqlStr, conn);
            MySqlDataReader dr = cmd.ExecuteReader();     
            dataTable.Load(dr);
            conn.Close();
            return dataTable;
        }

        /// <summary>
        /// 执行增删改操作 传入sql语句 返回受影响的行数
        /// </summary>
        /// <param name="sqlStr">sql语句</param>
        /// <returns>受影响的行数</returns>
        public int ExecuteUpdate(string sqlStr)
        {
            MySqlConnection conn = Connect(); //连接数据库
            if (conn == null) return 0;
            conn.Open(); //打开数据库连接
            MySqlCommand cmd = new MySqlCommand(sqlStr, conn);
            int count = cmd.ExecuteNonQuery(); //返回受影响的行数
            conn.Close();
            return count;
        }
    }
}
