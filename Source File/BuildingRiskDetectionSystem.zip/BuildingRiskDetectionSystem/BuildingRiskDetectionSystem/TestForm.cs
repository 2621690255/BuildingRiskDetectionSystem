﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class TestForm : Form
    {
        private FormControlsResize formControlsResize = new FormControlsResize();
        private Device device = new Device();
        public TestForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OneNetConnect oneNetConnect = new OneNetConnect();
            textBox3.Text = oneNetConnect.Get(textBox1.Text, textBox2.Text);
            textBox4.Clear();
            if (device.InitializeData(textBox3.Text))
            {
                foreach (KeyValuePair<string, string> item in device.Data)
                {
                    textBox4.Text += item.Key.ToString() + " : " + item.Value.ToString() + "\r\n";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "/datastreams";
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Start();
            formControlsResize.Initialize(this);
        }

        private void Form4_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize(this);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string datapoints_id = "temp";
            string start = "2018-01-01T00:00:00";
            string end = DateTime.Now.ToString("yyyy'-'MM'-'dd") + "T23:59:59";
            string limit = 3.ToString();
            string url = textBox1.Text.Trim() + "/datapoints?datapoints_id=" + datapoints_id + "&start=" + start + "&end=" + end + "&limit=" + limit;
            string api_key = textBox2.Text.Trim();
            OneNetConnect oneNetConnect = new OneNetConnect();
            string oneNetStr = oneNetConnect.Get(url, api_key);
            textBox3.Text = oneNetStr;
            textBox4.Text = url + "\r\n";
            DataTable dataTable = oneNetConnect.GetRecordDataTable(oneNetStr);
            for(int i = 0; i < dataTable.Rows.Count; ++i)
            {
                textBox4.Text += dataTable.Rows[i][0].ToString() + ":" + dataTable.Rows[i][1].ToString() + "\r\n";
            }   
        }

        static bool ledon = false;
        private void button4_Click(object sender, EventArgs e)
        {
            string contend = ledon ? "LEDOFF" : "LEDON";
            ledon = !ledon;
            OneNetConnect oneNetConnect = new OneNetConnect();
            string url = textBox1.Text.Trim().Substring(0, "http://api.heclouds.com/".Length);
            url += "cmds?device_id=" + Device.GetDeviceIdFromUrl(textBox1.Text.Trim());
            textBox4.Text = oneNetConnect.Post(url, textBox2.Text, contend);
        }
    }
}
