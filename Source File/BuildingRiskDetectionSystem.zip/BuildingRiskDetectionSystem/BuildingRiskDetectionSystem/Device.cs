﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BuildingRiskDetectionSystem
{
    class Device
    {
        public static string[] allDeviceType = { "温度", "湿度", "漏水检测", "人体闯入检测", "火灾监测", "窗户玻璃情况", "水阀", "可燃气体浓度", "CO浓度", "灰尘和烟尘含量", "空气质量", "其他" };
        public static string[] oneNetApiName = { "temp", "shidu", "loushui", "", "huozai", "chuanghu", "shuifa", "keranqi", "CO2", "huichen", "kongqi","" };
        public static string[] allDataUnit = { "℃", "%", "", "", "", "", "", "", "PPM", "PPM", "ug/m3", "PPM", "" };
        string device_id;
        string device_name;
        string device_type;
        string url;
        string api_key;
        Dictionary<string, string> data;

        public Device()
        {
            device_id = device_name = device_type = url = api_key = string.Empty;
        }
        /// <summary>
        /// 参数id,name,type,url,api_key
        /// </summary>
        /// <param name="vs"></param>
        public Device(string[] vs)
        {
            device_id = vs[0];
            device_name = vs[1];
            device_type = vs[2];
            url = vs[3];
            api_key = vs[4];
        }
        public Device(DataTable dataTable)
        {
            device_id = dataTable.Rows[0]["device_id"].ToString();
            device_name = dataTable.Rows[0]["device_name"].ToString();
            device_type = dataTable.Rows[0]["device_type"].ToString();
            url = dataTable.Rows[0]["url"].ToString();
            api_key = dataTable.Rows[0]["api_key"].ToString();
        }

        /// <summary>
        /// 根据oneNet返回的字符串，处理首个匹配{}中的内容
        /// </summary>
        /// <param name="oneNetStr"></param>
        public bool InitializeData(string oneNetStr)
        {
            /*
             *{
             *    "errno": 0,
             *    "data": {
             *        "update_at": "2021-11-02 17:03:11",
             *        "unit": "",
             *        "id": "temp",
             *        "create_time": "2021-11-02 16:52:39",
             *        "unit_symbol": "",
             *        "current_value": 44
             *    },
             *    "error": "succ"
             *}
             */
            if (oneNetStr == string.Empty) return false;
            Stack<int> vs = new Stack<int>();
            for (int i = 0; i < oneNetStr.Length; ++i)
            {
                if (oneNetStr[i] == '{')
                {
                    vs.Push(i);
                }
                else if (oneNetStr[i] == '}')
                {
                    string dataStr = oneNetStr.Substring(vs.Peek() + 1, i - vs.Peek() - 1);
                    data = GetData(dataStr);
                    vs.Pop();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 除了所有形如"key":value的字符串存入data
        /// </summary>
        /// <param name="dataStr"></param>
        /// <returns></returns>
        private Dictionary<string, string> GetData(string dataStr)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string[] vs = dataStr.Split(',');
            foreach (string item in vs)
            {
                string key = string.Empty;
                string value = string.Empty;
                //"update_at": "2021-11-02 17:03:11"
                for (int i = 1; i < item.Length; ++i)
                {
                    if (item[i] == '\"')
                    {
                        i += 2;
                        value = item[i] != '\"' ? item.Substring(i, item.Length - i) : item.Substring(i + 1, item.Length - i - 2);
                        break;
                    }
                    else key += item[i];
                }
                dic[key] = value;
            }
            return dic;
        }

        static public string GetDeviceIdFromUrl(string url)
        {
            //http://api.heclouds.com/devices/820069991
            int start = "http://api.heclouds.com/devices/".Length;
            return url.Substring(start, url.Length - start);
        }

        public string GetDeviceType()
        {
            string[] type = device_type.Split(',');
            return type[1];
        }

        /// <summary>
        /// 设备唯一码"device_id/device_type"
        /// </summary>
        /// <returns></returns>
        public string GetDeviceUniqueCode()
        {
            return device_id + "/" + device_type;
        }

        public string GetDataUnit()
        {
            return allDataUnit[GetIdx()];
        }

        public bool IsOnline()
        {
            OneNetConnect oneNetConnect = new OneNetConnect();
            string result  = oneNetConnect.Get(url, api_key);
            return result.Contains("\"online\":true");
        }

        public int GetIdx()
        {
            for (int i = 0; i < allDeviceType.Length; ++i)
            {
                string[] type = device_type.Split(',');
                if (type[0] == allDeviceType[i])
                {
                    return i;
                }
            }
            return allDeviceType.Length - 1;
        }

        public Dictionary<string, string> Data
        {
            get
            {
                return data;
            }
        }

        public string Device_name
        {
            get
            {
                return device_name;
            }
            set
            {
                device_name = value;
            }
        }

        public string Device_id
        {
            get
            {
                return device_id;
            }
            set
            {
                device_id = value;
            }
        }

        public string Device_type
        {
            get
            {
                return device_type;
            }
            set
            {
                device_type = value;
            }
        }

        public string Url
        {
            get
            {
                return url;
            }
            set
            {
                url = value;
            }
        }

        public string Api_key
        {
            get
            {
                return api_key;
            }
            set
            {
                api_key = value;
            }
        }
    }

}
