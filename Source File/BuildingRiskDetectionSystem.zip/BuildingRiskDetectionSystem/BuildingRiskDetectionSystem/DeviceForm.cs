﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class DeviceForm : Form
    {
        private FormControlsResize formControlsResize = new FormControlsResize();
        private FormControlsResize groupbox1ControlsResize = new FormControlsResize();
        private FormControlsResize groupbox2ControlsResize = new FormControlsResize();
        private Device device = new Device();
        private string uid = string.Empty;
        public DeviceForm()
        {
            InitializeComponent();
        }

        public DeviceForm(Control item)
        {
            InitializeComponent();
            device = (Device)item.Tag;
        }

        public DeviceForm(string uid, Control item)
        {
            InitializeComponent();
            this.uid = uid;
            device = (Device)item.Tag;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Load_Device_Data()
        {
            textBox1.Text = device.Device_id;
            textBox2.Text = device.Device_name;
            textBox3.Text = device.Device_type;
            textBox4.Text = device.Url;
            textBox5.Text = device.Api_key;
            label9.Text = device.GetDataUnit();
        }

        private void Get_Device_Data()
        {
            textBox6.Text = string.Empty;
            textBox7.Text = string.Empty;
            if (device.Data != null)
            {
                if (device.Data.ContainsKey("current_value")) textBox6.Text = device.Data["current_value"];
                else textBox6.Text = "no data";
                if (device.GetDataUnit() != "") label9.Text = device.GetDataUnit();
                else if (device.Data.ContainsKey("unit_symbol")) label9.Text = device.Data["unit_symbol"];
                else label9.Text = "unknow";
                if (device.Data.ContainsKey("update_at")) textBox7.Text = device.Data["update_at"];
                else textBox7.Text = "no data";
            }
            if (device.IsOnline()) roundButton1.GreenColor();
            else roundButton1.RedColor();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            timer1.Start();
            if (uid == string.Empty)
            {
                toolStripStatusLabel1.Text = "游客模式";
            }
            else
            {
                toolStripStatusLabel1.Text = "当前登入账号：" + uid;
            }
            formControlsResize.Initialize2(this);
            groupbox1ControlsResize.Initialize(groupBox1);
            groupbox2ControlsResize.Initialize(groupBox2);
            Load_Device_Data();
        }

        private void Form6_ResizeBegin(object sender, EventArgs e)
        {

        }

        private void Form6_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize2(this);
            groupbox1ControlsResize.Resize(groupBox1);
            groupbox2ControlsResize.Resize(groupBox2);
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox_Paint(object sender, PaintEventArgs e)
        {
            GroupBox gBox = (GroupBox)sender;

            e.Graphics.Clear(gBox.BackColor);
            e.Graphics.DrawString(gBox.Text, gBox.Font, Brushes.Black, 10, 1);
            var vSize = e.Graphics.MeasureString(gBox.Text, gBox.Font);
            e.Graphics.DrawLine(Pens.Black, 1, vSize.Height / 2, 8, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, vSize.Width + 8, vSize.Height / 2, gBox.Width - 2, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, 1, vSize.Height / 2, 1, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, 1, gBox.Height - 2, gBox.Width - 2, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, gBox.Width - 2, vSize.Height / 2, gBox.Width - 2, gBox.Height - 2);
        }
        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            groupBox_Paint(sender, e);
        }

        private void groupBox2_Paint(object sender, PaintEventArgs e)
        {
            groupBox_Paint(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OneNetConnect oneNetConnect = new OneNetConnect();
            string dataUrl = device.Url + "/datastreams/" + device.GetDeviceType();
            string oneNetStr = oneNetConnect.Get(dataUrl, device.Api_key);
            device.InitializeData(oneNetStr);
            Get_Device_Data();
        }

        private void Turn_Device_Led(bool flag)
        {
            //http://api.heclouds.com/cmds?device_id=843418893
            //http://api.heclouds.com/devices/843418893
            string contend = flag ? "LEDON" : "LEDOFF";
            OneNetConnect oneNetConnect = new OneNetConnect();
            string url = device.Url.Substring(0, "http://api.heclouds.com/".Length);
            url += "cmds?device_id=" + device.Device_id;
            oneNetConnect.Post(url, device.Api_key, contend) ;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (device.IsOnline()) roundButton1.GreenColor();
            else roundButton1.RedColor();
            if (roundButton1.IsGreenColor())
            {
                if(button3.Text == "打开警报")
                {
                    Turn_Device_Led(true);
                    button3.Text = "关闭警报";
                }
                else
                {
                    Turn_Device_Led(false);
                    button3.Text = "打开警报";
                }
            }
            else
            {
                MessageBox.Show("当前设备未在线！", "操作失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Control control = new Control();
            control.Tag = device;
            RecordForm form7 = new RecordForm(uid, control);
            form7.ShowDialog();
        }

        private bool User_Update_Device()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            device.Device_name = textBox2.Text.Trim();
            string sqlStr = "UPDATE user_device_tb SET device_name = '" + device.Device_name
                + "' WHERE uid = '" + uid
                + "' AND device_id = '" + device.Device_id
                + "'AND device_type = '" + device.Device_type
                + "';";
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        private bool Tourist_Update_Device()
        {
            device.Device_name = textBox2.Text.Trim();
            MainMenuForm.Tourist_Temp_Device.Tag = device;
            return true;
        }

        private bool Update_Device_Name()
        {
            if(uid == string.Empty)
            {
                return Tourist_Update_Device();
            }
            else
            {
                return User_Update_Device();
            }          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() != string.Empty)
            {
                if (Update_Device_Name())
                {
                    MessageBox.Show("设备信息已修改！", "修改成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MainMenuForm.NeedRefresh = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("设备信息修改失败！", "修改错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("设备名称不可为空！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Text = device.Device_name;
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
