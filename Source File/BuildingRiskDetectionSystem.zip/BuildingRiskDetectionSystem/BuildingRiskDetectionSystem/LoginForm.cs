﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class LoginForm : Form
    {
        FormControlsResize formControlsResize = new FormControlsResize();

        public LoginForm()
        {
            InitializeComponent();
        }

        private const String DEFAULT_TEXT = "3306";

        private void text_Enter(object sender, EventArgs e)
        {
            if (toolStripTextBox2.Text == DEFAULT_TEXT)
            {
                //清空文本框
                toolStripTextBox2.Text = "";
                toolStripTextBox2.ForeColor = Color.Black;
            }

        }

        private void SetDefaultText()
        {
            //默认文本
            toolStripTextBox2.Text = DEFAULT_TEXT;
            //默认文本颜色为灰色
            toolStripTextBox2.ForeColor = Color.Gray;
        }

        private void text_Leave(object sender, EventArgs e)
        {
            //如果文本框为空，则显示默认文本
            if (String.IsNullOrEmpty(toolStripTextBox2.Text))
            {
                //默认文本
                SetDefaultText();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            formControlsResize.Initialize(this);//调用方法
            label4.Text = label5.Text = string.Empty;

            SetDefaultText();
            toolStripTextBox2.GotFocus += new EventHandler(text_Enter);
            toolStripTextBox2.LostFocus += new EventHandler(text_Leave);

            timer1.Start();
        }

      
        private void Form1_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize(this);//随窗体改变控件大小
        }

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {          
            string uid = textBox1.Text;
            string pwd = textBox2.Text;
            if (uid == string.Empty) {
                label4.Text = "账号不能为空";
                return;
            }
            if(pwd == string.Empty){
                label5.Text = "密码不能为空";
                return;
            }
            string sqlStr = "SELECT * FROM user_tb WHERE uid = '" + uid + "';";
            MySQLConnect mySQLConnect = new MySQLConnect();
            DataTable dataTable = mySQLConnect.ExecuteQuery(sqlStr);

            if(dataTable.Rows.Count == 0)
            {
                MessageBox.Show("账号" + uid + "不存在，请重新输入或注册账号！" , "无效账号", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(dataTable.Rows[0]["pwd"].ToString() == pwd)
            {
                this.Hide();
                MainMenuForm form2 = new MainMenuForm(uid);
                form2.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("账号" + uid + "与密码不匹配，请重新输入！", "密码错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar >= (char)33 && e.KeyChar <= (char)126 || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text != string.Empty)
            {
                label4.Text = string.Empty;
            }
            else
            {
                label4.Text = "账号不能为空";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != string.Empty)
            {
                label5.Text = string.Empty;
            }
            else
            {
                label5.Text = "密码不能为空";
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsUpper(e.KeyChar) || Char.IsLower(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void 游客模式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuForm form2 = new MainMenuForm();
            form2.ShowDialog();
            this.Show();
        }

        private void 用户注册ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegisterForm form3 = new RegisterForm();
            form3.ShowDialog();
        }

        private void 帮助手册ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TestForm form4 = new TestForm();
            form4.ShowDialog();
        }

        private void 开发者工具ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void 连接数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void toolStripTextBox1_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void toolStripTextBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void toolStripTextBox2_TextChanged(object sender, EventArgs e)
        {
            MySQLConnect.SetMySqlAdress(toolStripTextBox2.Text.Trim());
        }
    }
}


