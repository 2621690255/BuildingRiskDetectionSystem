﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class RecordForm : Form
    {
        private FormControlsResize formControlsResize = new FormControlsResize();
        private string uid = string.Empty;
        Device device = new Device();
        public RecordForm()
        {
            InitializeComponent();
        }
        public RecordForm(string uid, Control control)
        {
            InitializeComponent();
            this.uid = uid;
            device = (Device)control.Tag;
        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

        }

        private DataTable Load_Data_From_RandomSeed()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("device_id", typeof(String));
            dataTable.Columns.Add("value", typeof(String));
            dataTable.Columns.Add("at", typeof(DateTime));
            Random random = new Random();
            int count = random.Next(1, 11);
            for (int i = 0; i < count; ++i)
            {
                int value = random.Next(0, 101);
                int time = random.Next(0, 60 * 60 * 24 * 365);
                dataTable.Rows.Add("Random", value.ToString(), DateTime.Now.AddSeconds(-time));
            }
            return dataTable;
        }

        private void Tourist_Load()
        {        
            Data_Load_To_DataGridView(Load_Data_From_RandomSeed());
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Now.AddMonths(-1);
            dateTimePicker2.Value = DateTime.Now;
            if (uid == string.Empty)
            {
                toolStripStatusLabel1.Text = "游客模式";
                Tourist_Load();
            }
            else
            {
                toolStripStatusLabel1.Text = "当前登入账号：" + uid;
                User_Load();
            }
            timer1.Start();
            formControlsResize.Initialize2(this);
            //formControlsResize.Initialize(statusStrip1);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void Data_Load_To_DataGridView(DataTable dataTable)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dataTable;
            dataGridView1.Columns["value"].DataPropertyName = dataTable.Columns["value"].ToString();
            dataGridView1.Columns["at"].DataPropertyName = dataTable.Columns["at"].ToString();
        }

        private DataTable Load_Data_From_OneNet()
        {
            string datastream_id = device.GetDeviceType();
            string start = dateTimePicker1.Value.ToString("yyyy'-'MM'-'dd") + "T00:00:00";
            string end = dateTimePicker2.Value.ToString("yyyy'-'MM'-'dd") + "T23:59:59";
            string limit = numericUpDown1.Value.ToString();
            string url = device.Url + "/datapoints?datastream_id=" + datastream_id + "&start=" + start + "&end=" + end + "&limit=" + limit;
            //MessageBox.Show(url);
            OneNetConnect oneNetConnect = new OneNetConnect();
            string oneNetStr = oneNetConnect.Get(url, device.Api_key);
            DataTable dataTable = new DataTable();
            dataTable = oneNetConnect.GetRecordDataTable(oneNetStr);
            return dataTable;
        }

        private void User_Load()
        {
            Data_Load_To_DataGridView(Load_Data_From_Mysql());
        }

        private DataTable Load_Data_From_Mysql()
        {
            string start = dateTimePicker1.Value.ToString("yyyy'-'MM'-'dd") + " 00:00:00";
            string end = dateTimePicker2.Value.ToString("yyyy'-'MM'-'dd") + " 23:59:59";
            string limit = numericUpDown1.Value.ToString();
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "SELECT * FROM record_tb WHERE device_id = '" + device.Device_id
                + "' AND device_type = '" + device.Device_type
                + "' AND at BETWEEN '" + start
                + "' AND '" + end
                + "' LIMIT " + limit
                + ";";
            DataTable dataTable = new DataTable();
            dataTable = mySQLConnect.ExecuteQuery(sqlStr);
            return dataTable;
        }

        private void OneNet_Load()
        {
            Data_Load_To_DataGridView(Load_Data_From_OneNet());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value > dateTimePicker2.Value)
            {
                DateTime tmp = dateTimePicker2.Value;
                dateTimePicker2.Value = dateTimePicker1.Value;
                dateTimePicker1.Value = tmp;
            }
            if (radioButton1.Checked)
            {
                OneNet_Load();
            }
            else
            {
                if (uid == string.Empty) Tourist_Load();
                else User_Load();
            }
        }

        private void Form7_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize2(this);
            //formControlsResize.Resize(statusStrip1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
