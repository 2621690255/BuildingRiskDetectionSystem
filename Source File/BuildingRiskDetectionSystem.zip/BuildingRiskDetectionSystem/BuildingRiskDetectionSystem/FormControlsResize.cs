﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    /// <summary>
    /// 一个使窗体控件大小随窗体大小变化而变化的类
    /// </summary>
    class FormControlsResize
    {
        private float X; //原始窗体的宽度
        private float Y; //原始窗体的高度
        /// <summary>
        /// 初始化，cons为当前窗体
        /// </summary>
        /// <param name="cons">递归控件中的控件</param>
        /// /// 将控件的宽，高，左边距，定边距和字体大小暂存到tag属性中
        public void Initialize(Control cons)
        {
            X = cons.Width;//获取窗体的宽度
            Y = cons.Height;//获取窗体的高度
            foreach (Control con in cons.Controls)
            {
                con.Tag = con.Width + ":" + con.Height + ":" + con.Left + ":" + con.Top + ":" + con.Font.Size;
                if (con.Controls.Count > 0)
                    Initialize(con);
            }
        }

        public void Initialize2(Control cons)
        {
            int count = cons.Controls.Count * 2 + 2;
            float[] factor = new float[count];
            int i = 0;
            factor[i++] = cons.Size.Width;
            factor[i++] = cons.Size.Height;
            foreach (Control ctrl in cons.Controls)
            {
                factor[i++] = ctrl.Location.X / (float)cons.Size.Width;
                factor[i++] = ctrl.Location.Y / (float)cons.Size.Height;
                ctrl.Tag = ctrl.Size;

                //if (ctrl.Controls.Count > 0) Initialize(ctrl);
            }
            cons.Tag = factor;
        }

        public void Resize2(Control cons)
        {
            float[] scale = (float[])cons.Tag;
            int i = 2;

            foreach (Control ctrl in cons.Controls)
            {
                ctrl.Left = (int)(cons.Size.Width * scale[i++]);
                ctrl.Top = (int)(cons.Size.Height * scale[i++]);
                ctrl.Width = (int)(cons.Size.Width / (float)scale[0] * ((Size)ctrl.Tag).Width);
                ctrl.Height = (int)(cons.Size.Height / (float)scale[1] * ((Size)ctrl.Tag).Height);

                //每次使用的都是最初始的控件大小，保证准确无误。

                //if (ctrl.Controls.Count > 0) Resize(ctrl);
            }
        }
        ///<summary>
        ///调整控件大小，cons为当前窗体
        /// </summary>
        /// <param name="cons">当前窗体</param>
        public void Resize(Control cons)
        {
            float newx = cons.Width / X;
            float newy = cons.Height / Y;
            setControls(newx, newy, cons);
        }

        ///<summary>
        ///根据窗体大小调整控件大小
        /// </summary>
        private void setControls(float newx, float newy, Control cons)
        {
            //遍历窗体中的控件，重新设置控件的值
            foreach (Control con in cons.Controls)
            {
                string[] mytag = con.Tag.ToString().Split(new char[] { ':' });//获取控件的Tag属性值，并分割后存储字符串数组
                float a = System.Convert.ToSingle(mytag[0]) * newx;//根据窗体缩放比例确定控件的值，宽度
                con.Width = (int)a;//宽度
                a = System.Convert.ToSingle(mytag[1]) * newy;//高度
                con.Height = (int)(a);
                a = System.Convert.ToSingle(mytag[2]) * newx;//左边距离
                con.Left = (int)(a);
                a = System.Convert.ToSingle(mytag[3]) * newy;//上边缘距离
                con.Top = (int)(a);
                Single currentSize = System.Convert.ToSingle(mytag[4]) * newy;//字体大小

                con.Font = new Font(con.Font.Name, currentSize, con.Font.Style, con.Font.Unit);
                if (con.Controls.Count > 0)
                {
                    setControls(newx, newy, con);
                }
            }
        }
    }
}
