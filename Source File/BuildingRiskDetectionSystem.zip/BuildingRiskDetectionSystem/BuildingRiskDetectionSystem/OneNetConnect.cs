﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    /// <summary>
    /// 一个连接云平台OneNet的类
    /// </summary>
    class OneNetConnect
    {
        /// <summary>
        /// bool 判断url地址是否可用
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private bool IsAvaliableUrl(string url)
        {
            string http = url.Substring(0, url.Length < 7 ? url.Length : 7);
            string https = url.Substring(0, url.Length < 8 ? url.Length : 8);
            try
            {
                if (http != "http://" && https != "https://")
                {
                    MessageBox.Show("url必须以http://或https://开头", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else return true;
            }
            catch
            {
                MessageBox.Show("url必须以http://或https://开头", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }
        /// <summary>
        /// HttpWebResponse 获取http回应
        /// </summary>
        /// <param name="url"></param>
        /// <param name="api_key"></param>
        /// <returns></returns>
        private HttpWebResponse GetConnect(string url, string api_key)
        {
            if (!IsAvaliableUrl(url)) return null;
            //string url = "http://api.heclouds.com/devices/804632405/datastreams";//设备地址
            
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                //SetHeaderValue(request.Headers, "api-key", "U7UU2Hp4ns2V2Ug55BgrHGinQYA=");//设备API地址和 首部参数
                SetHeaderValue(request.Headers, "api-key", api_key);//设备API地址和 首部参数
                request.Host = "api.heclouds.com";
                request.ProtocolVersion = new Version(1, 1);
                request.ContentType = "text/html;charset=UTF-8";
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    //MessageBox.Show("url请求回应成功！", "连接信息");
                    return response;
                }
                else
                {
                    MessageBox.Show("url请求回应失败！", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("url请求回应失败！", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }
        /// <summary>
        /// 传入url、api_key，从oneNet获取数据
        /// </summary>
        /// <param name="url"></param>
        /// <param name="api_key"></param>
        /// <returns></returns>
        public string Get(string url, string api_key)
        {
            HttpWebResponse response = GetConnect(url, api_key);
            if (response == null) return string.Empty;
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        /// <summary>
        /// 传入url、api_key、content，向oneNet发送数据
        /// </summary>
        /// <param name="url"></param>
        /// <param name="api_key"></param>
        /// <param name="content">post内容主体</param>
        /// <returns></returns>
        public string Post(string url, string api_key, string content)
        {
            //string url = "http://api.heclouds.com/cmds?device_id=843418893";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            SetHeaderValue(request.Headers, "api-key", api_key);//设备API地址和 首部参数
            request.Host = "api.heclouds.com";
            request.ProtocolVersion = new Version(1, 1);
            //string Cod = "LEDOFF";
            byte[] data = Encoding.UTF8.GetBytes(content);
            request.ContentLength = data.Length;
            using (Stream reqStream = request.GetRequestStream())
            {
                reqStream.Write(data, 0, data.Length);
                reqStream.Close();
            }

            HttpWebResponse resp = (HttpWebResponse)request.GetResponse();
            Stream stream = resp.GetResponseStream();
            //获取响应内容 
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            {
                return reader.ReadToEnd();              
            }
            // return result;
        }

        /// <summary>
        /// 设置报文头
        /// </summary>
        /// <param name="header"></param>
        /// <param name="name"></param>
        /// <param name="value"></param>
        private void SetHeaderValue(WebHeaderCollection header, string name, string value)
        {
            var property = typeof(WebHeaderCollection).GetProperty("InnerCollection", BindingFlags.Instance | BindingFlags.NonPublic);
            if (property != null)
            {
                var collection = property.GetValue(header, null) as NameValueCollection;
                collection[name] = value;
            }
            //throw new NotImplementedException();
        }

        /// <summary>
        /// 获取errno码
        /// </summary>
        /// <param name="oneNetStr"></param>
        /// <returns></returns>
        private int GetErrno(string oneNetStr)
        {
            /*
             *{
             *    "errno": 3,
             *    "error": "auth failed: key: K=AoA5YDyoXu=5Ng7wDaivtyWlg"
             * }
             */
            string[] vs = oneNetStr.Split("{\"errno\":");
            int errno = -1;
            for(int i = 0; i < vs[1].Length; ++i)
            {
                if (vs[1][i] >= '0' && vs[1][i] <= '9')
                {
                    if (errno == -1) errno = vs[1][i] - '0';
                    else errno = errno * 10 + vs[1][i] - '0';
                }
                else break;
            }
            return errno;
        }

        /// <summary>
        /// 判断url、api_key是否可用
        /// </summary>
        /// <param name="url"></param>
        /// <param name="api_key"></param>
        /// <returns></returns>        
        public bool IsAvailable(string url, string api_key)
        {
            string oneNetStr = Get(url, api_key);
            if (oneNetStr == string.Empty) return false;
            if (GetErrno(oneNetStr) != 0) return false;
            return true;
        }

        /// <summary>
        /// 获取历史记录表
        /// </summary>
        /// <param name="oneNetStr"></param>
        /// <returns></returns>
        public DataTable GetRecordDataTable(string oneNetStr)
        {
            /*
             * {
             * "errno":0,
             * "data":{
             * "cursor":
             * "465310_803954396_1635843751361",
             * "count":3,
             * "datastreams":
             * [{"datapoints":
             * [
             * {"at":"2021-11-02 17:02:31.361","value": 50},
             * {"at":"2021-11-02 16:53:08.074","value":"80\r"},
             * {"at":"2021-11-02 16:53:41.808","value":"70\r"}
             * ],
             * "id":"temp"}]},
             * "error":"succ"
             * }
             */
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("at", typeof(String));
            dataTable.Columns.Add("value", typeof(String));
            Stack<int> vs = new Stack<int>();
            for(int i = 0; i < oneNetStr.Length; ++i)
            {
                if(oneNetStr[i] == '[')
                {
                    vs.Push(i);
                }
                else if(oneNetStr[i] == ']')
                {
                    string[] dataPoints = oneNetStr.Substring(vs.Peek() + 1, i - vs.Peek() - 1).Split("},");               
                    foreach(string Str in dataPoints)
                    {
                        //{"at":"2021-11-02 17:02:31.361","value":50
                        //{"at":"2021-11-02 16:53:08.074","value":"80\r"
                        //{"at":"2021-11-02 16:53:41.808","value":"70\r"}
                        if (!Str.Contains("at") || !Str.Contains("value")) continue;
                        string at = Str.Substring(7, 19);
                        string value = string.Empty;
                        int idx = "{\"at\":\"2021-11-02 16:53:41.808\",\"value\":".Length;
                        if (Str[idx] == '"') ++idx;
                        while (idx < Str.Length && Str[idx] != '"' && Str[idx] != '}')
                        {
                            if (Str[idx] == '\\') value += '\\';
                            value += Str[idx];
                            ++idx;
                        }
                        dataTable.Rows.Add(at, value);
                    }             
                    break;
                }
            }
            return dataTable;
        }
    }
}
