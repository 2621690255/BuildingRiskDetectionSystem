﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class AddDeviceForm : Form
    {
        private FormControlsResize formControlsResize = new FormControlsResize();
        Device device = new Device();
        private string uid = string.Empty;
        public AddDeviceForm()
        {
            InitializeComponent();
        }

        public AddDeviceForm(string uid)
        {
            InitializeComponent();
            this.uid = uid;
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            timer1.Start();
            comboBox1.SelectedIndex = 11;
            label6.Text = label7.Text = label8.Text = string.Empty;
            if (uid == string.Empty)
            {
                toolStripStatusLabel1.Text = "游客模式";
            }
            else
            {
                toolStripStatusLabel1.Text = "当前登入账号：" + uid;
            }
            formControlsResize.Initialize(this);
        }

        private void Form5_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string device_name = textBox1.Text.Trim();
            string url = textBox2.Text.Trim();
            string api_key = textBox3.Text.Trim();
            if (device_name == string.Empty)
            {
                label6.Text = "设备名称不可为空";
                return;
            }
            if(url == string.Empty)
            {
                label7.Text = "设备url不可为空";
                return;
            }
            if(api_key == string.Empty)
            {
                label8.Text = "设备api-key不可为空";
                return;
            }                    

            OneNetConnect oneNetConnect = new OneNetConnect();
            if(oneNetConnect.IsAvailable(url, api_key))
            {
                roundButton1.GreenColor();
            }
            else
            {
                roundButton1.RedColor();
                MessageBox.Show("请检查设备url和api_key是否正确！", "设备不可用", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            roundButton1.RedColor();
            if (textBox2.Text.Length == 0)
            {
                label7.Text = "设备url不可为空";
            }
            else
            {
                label7.Text = string.Empty;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            roundButton1.RedColor();
            if (textBox3.Text.Length == 0)
            {
                label8.Text = "设备api-key不可为空";
            }
            else
            {
                label8.Text = string.Empty;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text.Length == 0)
            {
                label6.Text = "设备名称不可为空";
            }
            else
            {
                label6.Text = string.Empty;
            }
        }

        private bool IsUserHasDevice()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "SELECT * FROM user_device_tb WHERE uid = '" + uid
                + "' AND device_id = '" + device.Device_id 
                + "' AND device_type = '" + device.Device_type
                + "';";
            DataTable dt = mySQLConnect.ExecuteQuery(sqlStr);
            return dt.Rows.Count != 0;
        }

        private bool UserAddDevice()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "INSERT INTO user_device_tb VALUES('" + uid
                + "','" + device.Device_id
                + "','" + device.Device_type
                + "','" + device.Device_name
                + "');";
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        private bool IsDeviceExist()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "SELECT * FROM device_tb WHERE device_id = '" + device.Device_id + "';";
            DataTable dataTable = new DataTable();
            dataTable = mySQLConnect.ExecuteQuery(sqlStr);
            return dataTable.Rows.Count != 0;
        }

        private bool AddDevice()
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "INSERT INTO device_tb VALUES('" + device.Device_id
                + "','"
                + "','"
                + "','" + device.Url
                + "','" + device.Api_key
                + "');";
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        private void User_Mode()
        {
            if (!IsDeviceExist())
            {
                if (!AddDevice())
                {
                    MessageBox.Show("设备添加失败！", "添加错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                //MessageBox.Show("设备添加成功！", "添加成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (!IsUserHasDevice())
            {
                if (UserAddDevice())
                {
                    MessageBox.Show("该设备已成功加入您的库中！", "添加成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MainMenuForm.NeedRefresh = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("用户添加设备失败！", "添加错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("用户库中已存在同一设备！", "重复添加", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        
        private void Tourist_Mode()
        {
            MainMenuForm.Tourist_Temp_Device.Tag = device;
            MessageBox.Show("该设备已成功加入您的库中！", "添加成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MainMenuForm.NeedRefresh = true;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {                                
            if (roundButton1.IsGreenColor())
            {
                device.Device_id = Device.GetDeviceIdFromUrl(textBox2.Text.Trim());
                device.Device_name = textBox1.Text.Trim();
                device.Url = textBox2.Text.Trim();
                device.Api_key = textBox3.Text.Trim();
                device.Device_type = comboBox1.Text.ToString() + "," + textBox4.Text.Trim();
                if(uid == string.Empty)
                {
                    Tourist_Mode();
                }
                else
                {
                    User_Mode();  
                }               
            }
            else
            {
                MessageBox.Show("请先检测设备是否可用！", "添加错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox4.Text = Device.oneNetApiName[comboBox1.SelectedIndex];
        }
    }
}
