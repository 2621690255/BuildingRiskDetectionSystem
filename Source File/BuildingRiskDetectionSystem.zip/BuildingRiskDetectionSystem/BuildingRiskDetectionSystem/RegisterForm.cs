﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BuildingRiskDetectionSystem
{
    public partial class RegisterForm : Form
    {
        FormControlsResize formControlsResize = new FormControlsResize();
        private string userPassWord;
        public RegisterForm()
        {
            InitializeComponent();
        }

        private bool CancelUserAccount(string uid)
        {
            string sqlStr = "DELETE FROM user_device_tb WHERE uid = '" + uid + "';";
            MySQLConnect mySQLConnect = new MySQLConnect();
            mySQLConnect.ExecuteUpdate(sqlStr);
            sqlStr = "DELETE FROM user_tb WHERE uid = '" + uid + "';";       
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        /// <summary>
        /// 注销账号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty)
            {
                label4.Text = "账号不能为空";
                return;
            }
            if (textBox2.Text == string.Empty)
            {
                label5.Text = "密码不能为空";
                return;
            }
            if (textBox3.Text == string.Empty)
            {
                label6.Text = "请确认密码";
                return;
            }
            int result = CheckUserAccount(textBox1.Text, textBox2.Text, textBox3.Text);
            if(result == 3)
            {
                if(textBox2.Text != userPassWord)
                {
                    MessageBox.Show("账号" + textBox1.Text + "与密码不匹配，请重新输入！", "密码错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult dialogResult = MessageBox.Show("是否注销账号" + textBox1.Text + "？请注意此操作不可逆！", "注销确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if(dialogResult == DialogResult.Yes)
                {
                    if (CancelUserAccount(textBox1.Text))
                    {
                        MessageBox.Show("账号" + textBox1.Text + "已被注销！", "注销成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("注销失败！", "注销错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else if(result == 2)
            {
                MessageBox.Show("两次输入密码不相同！", "密码错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("账号" + textBox1.Text + "不存在!", "账号无效", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Start();
            formControlsResize.Initialize(this);
            label4.Text = label5.Text = label6.Text = string.Empty;
        }

        private void Form3_Resize(object sender, EventArgs e)
        {
            formControlsResize.Resize(this);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsUpper(e.KeyChar) || Char.IsLower(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= (char)33 && e.KeyChar <= (char)126 || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= (char)33 && e.KeyChar <= (char)126 || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 检测注册账号是否合法
        /// </summary>
        /// <param name="uid">用户账号</param>
        /// <param name="pwd1">第一次输入的密码</param>
        /// <param name="pwd2">第二次输入的密码</param>
        /// <returns>0账号不存在&密码不相同 1账号不存在&密码相同 2账号存在&密码不相同 3账号存在&密码相同</returns>
        private int CheckUserAccount(string uid, string pwd1, string pwd2)
        {
            string sqlStr = "SELECT * FROM user_tb WHERE uid = '" + uid + "';";
            MySQLConnect mySQLConnect = new MySQLConnect();
            DataTable dataTable = new DataTable();
            dataTable = mySQLConnect.ExecuteQuery(sqlStr);
            userPassWord = dataTable.Rows.Count == 0 ? string.Empty : dataTable.Rows[0]["pwd"].ToString();
            return Convert.ToInt32(dataTable.Rows.Count != 0) * 2 + Convert.ToInt32(pwd1 == pwd2);
        }

        /// <summary>
        /// 注册账号至数据库
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        private bool RegisterUserAccount(string uid, string pwd)
        {
            MySQLConnect mySQLConnect = new MySQLConnect();
            string sqlStr = "INSERT INTO user_tb VALUES('" + uid + "','" + pwd + "');";
            return mySQLConnect.ExecuteUpdate(sqlStr) == 1;
        }

        /// <summary>
        /// 注册账号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == string.Empty)
            {
                label4.Text = "账号不能为空";
                return;
            }
            if (textBox2.Text == string.Empty)
            {
                label5.Text = "密码不能为空";
                return;
            }
            if (textBox3.Text == string.Empty)
            {
                label6.Text = "请确认密码";
                return;
            }
            int result = CheckUserAccount(textBox1.Text, textBox2.Text, textBox3.Text);
            if(result == 0)
            {
                MessageBox.Show("两次输入密码不相同！", "密码错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(result == 1)
            {
                if (RegisterUserAccount(textBox1.Text, textBox2.Text))
                {
                    MessageBox.Show("注册成功，请牢记您的账号与密码！", "注册成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("注册失败！", "注册错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("账号" + textBox1.Text + "已存在！", "账号重复", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
             
            if (textBox1.Text != string.Empty)
            {
                label4.Text = string.Empty;
            }
            else
            {
                label4.Text = "账号不能为空";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != string.Empty)
            {
                label5.Text = string.Empty;
            }
            else
            {
                label5.Text = "密码不能为空";
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text != string.Empty)
            {
                label6.Text = string.Empty;
            }
            else
            {
                label6.Text = "请确认密码";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = "当前系统时间：" + DateTime.Now.ToString();
        }
    }
}
